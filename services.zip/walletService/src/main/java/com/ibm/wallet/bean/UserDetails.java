package com.ibm.wallet.bean;

import javax.annotation.processing.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class UserDetails {
	
	String fullName;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer userId;
	String email;
	String phone;
	String frontLicenseImageUrl;
	String backLicenseImageUrl;
	String password;
	
	UserDetails(){
		
	}
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getFrontLicenseImageUrl() {
		return frontLicenseImageUrl;
	}
	public void setFrontLicenseImageUrl(String frontLicenseImageUrl) {
		this.frontLicenseImageUrl = frontLicenseImageUrl;
	}
	public String getBackLicenseImageUrl() {
		return backLicenseImageUrl;
	}
	public void setBackLicenseImageUrl(String backLicenseImageUrl) {
		this.backLicenseImageUrl = backLicenseImageUrl;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getUserId() {
		return userId;
	}
	public String getEmail() {
		return email;
	}

	public UserDetails(Integer userId, String fullName, String email, String phone, String frontLicenseImageUrl,
			String backLicenseImageUrl, String password) {
		this.userId = userId;
		this.fullName = fullName;
		this.email = email;
		this.phone = phone;
		this.frontLicenseImageUrl = frontLicenseImageUrl;
		this.backLicenseImageUrl = backLicenseImageUrl;
		this.password = password;
	}
	
	
	
}
