package com.ibm.wallet.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.wallet.bean.Wallet;
import com.ibm.wallet.dao.WalletRepository;
import com.ibm.wallet.service.WalletService;



@RestController
public class WalletController {
	@Autowired
	WalletRepository repo;
	@Autowired
	WalletService service;
	
	@RequestMapping("/wallets/{userId}")
	Wallet getWalletByUserId(@PathVariable Integer userId) {

		return service.findByUserDetailsUserId(userId);
//		return repo.findByUserDetailsUserId(userId);		
	}
	
	@RequestMapping(method = RequestMethod.PUT,value = "/wallets/{walletId}/transaction")
	Double getTrans(@PathVariable Integer walletId){
		return service.updateWallet(walletId);
	}

}
