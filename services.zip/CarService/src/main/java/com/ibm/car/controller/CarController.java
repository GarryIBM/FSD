package com.ibm.car.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.car.bean.Car;
import com.ibm.car.service.CarService;

@RestController
@RequestMapping("/cars")
public class CarController {

	@Autowired
	CarService service;

	@RequestMapping("/list/{city}")
	List<Car> getAllCars(@PathVariable String city){
		
		return service.getAllCars(city);
		
	}
	
	
	@RequestMapping("/{modelno}")
	@CrossOrigin(origins = "http://localhost:4200")
	Optional<Car> getCarById(@PathVariable int modelno) {
		
		return service.getCarById(modelno);
	}
	
	@RequestMapping("cars/available/{city}")
	List<Car> getAvailableCars(@PathVariable String city){
		return service.getAvailableCars(city);
	}

}
