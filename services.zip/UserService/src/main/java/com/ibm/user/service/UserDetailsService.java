package com.ibm.user.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.user.bean.UserDetails;
import com.ibm.user.repository.UserDetailsRepository;

@Service
public class UserDetailsService {
	
	@Autowired
	UserDetailsRepository repo;
	
	public Iterable<UserDetails> getAllUsers(){
		return repo.findAll();
	}
	
	public Optional<UserDetails> getUserById(String id){
		return repo.findById(id);
	}

	public boolean addUser(UserDetails user) {
		boolean isUserExist=repo.existsById(user.getEmail());
		if(isUserExist==false) {
		repo.save(user);
		}
		return !isUserExist;
		
		
	}

	public boolean userLogin(UserDetails user) {
		boolean isUserExists=false;
		Optional<UserDetails> log=repo.findByEmailAndPassword(user.getEmail(),user.getPassword());
		if(log.isPresent()) {
			isUserExists=true;
		}
		
		return isUserExists;
	}
	
}
