package com.ibm.App.LocationRepository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ibm.App.LocationEntity.Locations;

public interface LocationRepository extends CrudRepository<Locations, Integer> {

	List<Locations> findByCity(String city);
}
