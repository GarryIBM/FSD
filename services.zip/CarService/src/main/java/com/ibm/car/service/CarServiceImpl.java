package com.ibm.car.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.car.bean.Car;
import com.ibm.car.repository.CarRepository;

@Service
public class CarServiceImpl implements CarService {
	
	@Autowired
	CarRepository dao;
	
	@Override
	public List<Car> getAllCars(String city) {
	
		return dao.findByCity(city);
	}

	@Override
	public Optional<Car> getCarById(int id) {
		return dao.findById(id);
	}

	@Override
	public List<Car>getAvailableCars(String city) {
		// TODO Auto-generated method stub
		return dao.fetchCarsByAvailability(city);
	}

	
	

	
}
