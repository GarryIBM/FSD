package com.ibm.car.service;

import java.util.List;
import java.util.Optional;

import com.ibm.car.bean.Car;

public interface CarService {

	List<Car> getAllCars(String city);

	Optional<Car> getCarById(int modelno);

	List<Car> getAvailableCars(String city);


}
