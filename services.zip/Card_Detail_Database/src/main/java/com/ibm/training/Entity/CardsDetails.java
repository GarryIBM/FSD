package com.ibm.training.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class CardsDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer cardId;
	
	String cardNum, expMonth, expYear, cvv, cardHolderName;
	
	public String getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	@ManyToOne
	UserDetails user;
	
	public CardsDetails() {}

	public String getCardNum() {
		return cardNum;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public String getExpMonth() {
		return expMonth;
	}

	public void setExpMonth(String expMonth) {
		this.expMonth = expMonth;
	}

	public String getExpYear() {
		return expYear;
	}

	public void setExpYear(String expYear) {
		this.expYear = expYear;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public UserDetails getUser() {
		return user;
	}

	public void setUser(UserDetails user) {
		this.user = user;
	}

	public CardsDetails(String cardNum, String expMonth, String expYear, String cvv, String cardHolderName, Integer userId) {
		this.cardNum = cardNum;
		this.expMonth = expMonth;
		this.expYear = expYear;
		this.cvv = cvv;
		this.cardHolderName = cardHolderName;
		this.user = new UserDetails(userId);
	}
	
	
}
