package com.ibm.car.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ibm.car.bean.Car;

@Repository
public interface CarRepository extends CrudRepository<Car, Integer> {
  List<Car > findByCity(String city);

  @Query(value = "select * from cars where city = :city and is_booked = 1", nativeQuery = true)
	List<Car> fetchCarsByAvailability(@Param(value = "city") String city);

}
