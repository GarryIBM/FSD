package com.ibm.training.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.training.Entity.CardsDetails;
import com.ibm.training.Service.CardService;

@RestController
public class CardController {
	
	@Autowired
	CardService service;
	
	@RequestMapping(method = RequestMethod.POST, value = "/user/{userId}/cards")
	void addCard(@RequestBody CardsDetails card, @PathVariable Integer userId) {
		service.addCard(card, userId);	
	}
	
	@RequestMapping("/user/{userId}/cards")
	List<CardsDetails> getCardsByUserId(@PathVariable Integer userId){
		return service.getCardsByUserId(userId);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value="/cards/{cardId}")
	void deleteCardById(@PathVariable int cardId) {
		service.deleteCardById(cardId);
	}
}
