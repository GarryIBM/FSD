package com.ibm.booking.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="bookings")
public class Booking {
	@Id
	@GeneratedValue( strategy = GenerationType.AUTO)
	Integer bookingId;
	
	String fromDate;
	
	String tillDate;
	
	Boolean status;
	
	@ManyToOne
	UserDetails userDetails;
	
	@OneToOne
	Car car;

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getTillDate() {
		return tillDate;
	}

	public void setTillDate(String tillDate) {
		this.tillDate = tillDate;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public Integer getBookingId() {
		return bookingId;
	}

	public Booking(String fromDate, String tillDate, Boolean status,String email, Integer bookingId, Integer carId) {
		super();
		this.fromDate = fromDate;
		this.tillDate = tillDate;
		this.status = status;
		this.userDetails = new UserDetails("", email,  "",  "",  "",  "", null);
		this.car = new Car(carId, "", "", "", null, null, "", "", "", true, null, "");
	}
	
	
	
}
